create table user_table
(user_id varchar2(30) Primary Key
,user_pwd varchar2(50)
,user_name varchar2(20)
,user_phone varchar2(20)
,user_email varchar2(50)
,user_addr varchar2(100)    
);