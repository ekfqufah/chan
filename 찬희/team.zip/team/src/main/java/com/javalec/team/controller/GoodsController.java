package com.javalec.team.controller;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.team.dto.GoodsDto;
import com.javalec.team.service.CartService;
import com.javalec.team.service.GoodsService;




@Controller
public class GoodsController {
	@Autowired
	private SqlSession sqlSession;
	
	@Autowired
	private GoodsService goodsService;
	
	
	
	public void getGoods(@RequestParam HashMap<String, String> param, Model model) {
		GoodsDto goodsdto = goodsService.getGoods(param);		
		model.addAttribute("goods",goodsdto);
	}
	
	@RequestMapping("/mainview")
	public String mainview() {
		return "mainview";
	}
	
	@RequestMapping("goodsDisplay")
	public String goodsDisplay(@RequestParam HashMap<String, String> param,Model model) {
		getGoods(param,model);
		return "goods/goodsDisplay";
	}
	
	
	@RequestMapping("/buy")
	public String buy(@RequestParam HashMap<String, String> param) {
		System.out.println(param.get("g_code"));
		System.out.println(param.get("g_name"));
		System.out.println(param.get("g_price"));
		System.out.println(param.get("c_amount"));
		int price = Integer.parseInt(param.get("g_price"))*Integer.parseInt(param.get("c_amount"));
		param.put("g_price", Integer.toString(price));
		goodsService.insertBuy(param);
		return "mainview";	
	}
	
	
	
	
	

}
