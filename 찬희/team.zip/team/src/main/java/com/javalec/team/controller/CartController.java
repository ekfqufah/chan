package com.javalec.team.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.team.dto.CartDto;
import com.javalec.team.service.CartService;





@Controller
public class CartController {
	@Autowired
	private SqlSession sqlSession;
	
	@Autowired
	private CartService cartservice; 
	
	
	


	@RequestMapping("/cartProcess")
	public String cartProcess(@RequestParam HashMap<String, String> param) {
//		System.out.println(param.get("g_code"));
//		System.out.println(param.get("g_name"));
//		System.out.println(param.get("g_price"));
		int price = Integer.parseInt(param.get("g_price"))*Integer.parseInt(param.get("c_amount"));
		param.put("g_price", Integer.toString(price));
//		System.out.println(param.get("c_amount"));
		cartservice.insertCart(param);
		return "mainview";	
	}
	
	@RequestMapping("/cartlist")
	public String cartlist(@RequestParam HashMap<String, String> param,Model model) {
		ArrayList<CartDto> cartlist =cartservice.getAllCart(param);
		model.addAttribute("cartlist",cartlist);
		return "goods/goodsDisplay";	
	}
	
	
	
	


}
