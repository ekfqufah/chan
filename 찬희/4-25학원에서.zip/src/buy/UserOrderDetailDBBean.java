package buy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import goods.GoodsDBBean;

public class UserOrderDetailDBBean {
	
	private static UserOrderDetailDBBean instance = new UserOrderDetailDBBean();
	 
	// UserDBBean ��ü �����ϴ� �޼��� - 0418 ����
	public static UserOrderDetailDBBean getInstance() {
		return instance;
	}
	
	// db�� �����ϴ� �޼��� - 0418 ����
	public Connection getConnection() throws Exception {
		Connection conn = null;
		conn = ((DataSource)(new InitialContext().lookup("java:comp/env/jdbc/oracle"))).getConnection();
		return conn;
	}
	
	
	
	
	public  ArrayList<UserOrderDetailBean> getUserOrderDetail(String user_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		String sql = "select * from user_order  where user_id = ?";
		
		ArrayList<UserOrderDetailBean> detailarr = new ArrayList<UserOrderDetailBean>();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_id);
			rs = pstmt.executeQuery();
			
			UserOrderDetailBean uodb = null;
			while (rs.next()) {
				System.out.println("��������ϳ�?");
				
				sql = "select * from userOrder_detail where order_number = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, rs.getString("order_number"));
				rs1 = pstmt.executeQuery();
				if(rs1.next()) {
					uodb = new UserOrderDetailBean();
					uodb.setOrder_detail_number(rs1.getInt("order_detail_number"));
					uodb.setOrder_number(rs1.getString("order_number"));
					uodb.setProduct_number(	rs1.getInt("product_number"));
					uodb.setProduct_count(rs1.getInt("product_count"));
					uodb.setProduct_count(rs1.getInt("product_price"));
					uodb.setOrder_detail_status(rs1.getString("order_detail_status"));
					detailarr.add(uodb);	
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return detailarr;
		}
	
	
	public int goodsRefundRequest(String order_number) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int re = -1;
		
		String query = "delete from userOrder_detail where order_number=?";
			try {
				conn = getConnection();
				pstmt = conn.prepareStatement(query);
				pstmt.setString(1,order_number);
				re = pstmt.executeUpdate();
				System.out.println("���� ����");
			} catch(Exception e) {
				e.printStackTrace();
				System.out.println("���� ����");
			} finally {
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			}
		
		
		return re;
	}
	
	
	
}
